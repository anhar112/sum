import unittest
from script import sum
class SumTest(unittest.testcase)

def test_sum(self):
    result = sum(3 , 5)
    self.assertEqual(result ,8)
def test_str_handling(self):
    result = sum("x" , "y") 
    self.assertEqual(result ,invalide input)
def test_handl_inputs(self):
    result = sum( "x", 5)
    self.assertEqual(result ,invalide input)

unittest.main()


def sum (x,y):
    try:
        result =int (x)+int(y)
    except:
        return "invalid input"    
    return x , y