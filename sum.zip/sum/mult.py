import unittest

def multiply(a, b):
    return a * b

class Test(unittest.TestCase):
    def test_multi(self):
        self.assertEqual(multiply(2, 3), 6)

    def test_multi2(self):
        self.assertEqual(multiply('s', 4), 8)

if _name_ == '_main_':
    unittest.main()