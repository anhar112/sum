def sum (x,y):
    try:
        result =int (x)+int(y)
    except:
        return "invalid input"    
    return x , y